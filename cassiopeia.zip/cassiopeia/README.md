# Cassiopeia

To run tests, first build the Docker image and run the container. Then, run Hardhat tests inside the container using ```npx hardhat test```.
Note that this will only work on Linux servers. The code has been tested on EC2 r5.xlarge machines.
